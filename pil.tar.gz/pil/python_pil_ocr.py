import glob
from pytesseract import *

list_dir = []
list_dir = glob.glob('./images/' + '*.jpg')

for jpg_file in list_dir:
    image=pytesseract.Image.open(jpg_file)
    ocr_txt_file = open(jpg_file + '_ocr.txt', 'w')
    ocr_txt_file.write(pytesseract.image_to_string(image))
    ocr_txt_file.close()
    print jpg_file + ' is parsed!'
