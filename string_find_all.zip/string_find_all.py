# -*- coding: cp936 -*-
## function: remove file 
## remark: python version 2-7-3

import re
import os

p = re.compile(r'56d\w+')

test_file_name = "test.json"

test_file_handler = open(test_file_name)
lines = test_file_handler.readlines()
test_file_handler.close()

for index, item in enumerate(lines):
    #print index
    print item
    result_list =  p.findall(item)
    for list_item in result_list:
        print list_item
